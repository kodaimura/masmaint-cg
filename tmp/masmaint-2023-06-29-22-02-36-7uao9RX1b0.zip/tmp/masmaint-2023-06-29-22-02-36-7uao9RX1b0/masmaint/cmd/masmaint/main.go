package main
 
import (
	"masmaint/core/server"
)
 
func main() {
	server.Run()
}